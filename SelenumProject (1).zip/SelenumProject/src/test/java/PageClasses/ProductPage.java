package PageClasses;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ProductPage {
    // WebDriver driver;
    public   static WebDriver driver;

    //constructor

    public  ProductPage (WebDriver driver){
        this.driver = driver;
    }

    //locators
    // static By garden = By.xpath("//a[@id='left-sidebar-links7-89qtwazjaojz8gyga6xqn2iqd']");
    static By colour = By.id("dk_container_Colour-229088");
    static By colour2 = By.xpath("//*[@id=\"dk_container_Colour-229088\"]/div/ul/li[4]/a");
    static By size = By.id("dk_container_Size-627-671");
    static By size2 = By.xpath("//*[@id=\"dk_container_Size-627-671\"]/div/ul/li[5]/a");
    static By addToBag = By.xpath("//a[contains(text(),'Add To Bag')]");
    static By editBag = By.xpath("//span[contains(text(),'VIEW/EDIT BAG')]");
   // static By addProduct = By.xpath("//tbody/tr[@id='3']/td[4]/div[1]/a[1]");
    static By addProduct = By.xpath("/html[1]/body[1]/section[1]/section[1]/div[1]/section[1]/div[2]/div[4]/div[2]/table[1]/tbody[1]/tr[1]/td[4]/div[1]/a[1]");
    static By choos2 = By.xpath("/html[1]/body[1]/section[1]/section[1]/div[1]/section[1]/div[2]/div[4]/div[2]/table[1]/tbody[1]/tr[1]/td[4]/div[1]/div[1]/ul[1]/li[2]/a[1]");
    static By checkout = By.xpath("//body/section[@id='ContentArea']/section[1]/div[1]/section[1]/div[2]/div[5]/div[3]/a[3]");


    // method for navigate to product page
    public static void navigateToProductPage() {
        driver.navigate().to("https://www.next.co.il/en/style/st289291/620712#620712");
    }
    // method for choose colour
    public static void chooseColour() {
        driver.findElement(colour).click();
        driver.findElement(colour2).click();
    }
    // method for choose size
    public static void chooseSize() {
        driver.findElement(size).click();
        driver.findElement(size2).click();
    }
    // method for click on AddToBag
    public static void addToBag() {
        driver.findElement(addToBag).click();
    }
    // method for click on editBag
    public static void editBag() {
        driver.findElement(editBag).click();
    }
    // method for click on checkout
    public static void checkout() {
        driver.findElement(checkout).click();
    }
    // method for click on addProduct
    public static void addProduct() {
        driver.findElement(addProduct).click();
    }
    // method for click on 2 in count from product
    public static void choos2() {
        driver.findElement(choos2).click();
    }


}
