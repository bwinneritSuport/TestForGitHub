package PageClasses;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LogInPage {

    // WebDriver driver;
    public static WebDriver driver;

    //constructor

    public  LogInPage (WebDriver driver){
        this.driver = driver;
    }

    //locators
    static By myAccount = By.xpath("//header/div[1]/nav[1]/div[3]/div[2]/div[1]/a[1]/span[1]");
    static By uname = By.xpath("//input[@id='EmailOrAccountNumber']");
    static By pass = By.xpath("//input[@id='Password']");
    static By login = By.xpath("//input[@id='SignInNow']");

    //method for click on my account

    public static void myAccount ()
    {driver.findElement(myAccount).click();}

    //method for enter uname

    public static void enteruname(String user)
    {driver.findElement(uname).sendKeys(user);}

    //method for enter password

    public static void enterPass (String password)
    {driver.findElement(pass).sendKeys(password);}

    //method for click on sing in

    public static void singIn ()
    {driver.findElement(login).click();}


}
