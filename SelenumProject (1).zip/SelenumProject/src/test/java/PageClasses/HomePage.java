package PageClasses;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class HomePage {

    // WebDriver driver;
    public   static WebDriver driver;

    //constructor

    public  HomePage (WebDriver driver){
        this.driver = driver;
    }

    //locators
   // static By garden = By.xpath("//a[@id='left-sidebar-links7-89qtwazjaojz8gyga6xqn2iqd']");
    public static By kitchenLeftLink = By.xpath("/html/body/section[1]/section[1]/div/div[1]/div[3]/div/div/div[2]/div[1]/div/div/div/div[1]/div[2]/div[7]/a");
    static By bathroomCenterLink = By.xpath("/html[1]/body[1]/section[1]/section[1]/div[1]/div[1]/div[3]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[2]/div[1]/div[2]/div[1]/div[1]/div[3]/a[1]");
    static By babyBannerLink = By.xpath("//header/div[@id='platform_modernisation_meganav']/div[1]/div[1]/div[1]/ul[1]/li[3]");
    //static By changeLanguage = By.className("component__Img-sc-1mfxoy5-3 hzkcon");
    static By changeLanguage = By.xpath("//header/div[1]/nav[1]/div[8]/div[1]/button[1]/img[1]");
    static By chooseLanguage = By.xpath("//button[contains(text(),'עברית')]");
    static By chooseLanguageToEnglish = By.xpath("//button[contains(text(),'English')]");
    static By shopNow = By.xpath("//span[contains(text(),'SHOP NOW')]");
    static By shopNowE = By.xpath("//span[contains(text(),'קנו עכשיו')]");
    static By search = By.xpath("//input[@id='header-big-screen-search-box']");
    static By iconSearch = By.xpath("//header/div[1]/nav[1]/div[2]/div[2]/div[1]/div[1]/form[1]/button[1]/span[1]/img[1]");




    //method for click on garden

  //  public static void garden ()
  //  {driver.findElement(garden).click();}

    //method for click on bathroom
    public static void bathroom ()
    {driver.findElement(bathroomCenterLink).click();}

    //method for click on kitchen
    public static void kitchen ()
    {driver.findElement(kitchenLeftLink).click();}

    //method for click on baby
    public static void baby ()
    {driver.findElement(babyBannerLink).click();}

    //method for click on changeLanguage
    public static void changeLanguage ()
    {driver.findElement(changeLanguage).click();}

    //method for click on chooseLanguage
    public static void chooseLanguage ()
    {driver.findElement(chooseLanguage).click();}

    //method for click on chooseLanguage to english
    public static void chooseLanguageBack ()
    {driver.findElement(chooseLanguageToEnglish).click();}

    //method for click on choose Language
    public static void shopNow ()
    {driver.findElement(shopNow).click();}

    //method for click on choose Language to english
    public static void shopNowE ()
    {driver.findElement(shopNowE).click();}

    //method for click on search
    public static void clickSearch ()
    {driver.findElement(search).click();}

    //method for search
    public static void search (String product)
    {driver.findElement(search).sendKeys(product);}

    //method for click on search icon
    public static void iconSearch ()
    {driver.findElement(iconSearch).click();}

    // method for navigate to home page
    public static void navigateToHomePage() {
      driver.navigate().to("https://www.next.co.il/en/homeware");
        // driver.navigate().to("https://www.next.co.il/en");
    }

}
