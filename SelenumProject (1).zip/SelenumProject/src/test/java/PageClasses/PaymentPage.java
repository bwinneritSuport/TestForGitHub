package PageClasses;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class PaymentPage {
    public   static WebDriver driver;

        //constructor

        public PaymentPage(WebDriver driver){
            this.driver = driver;
        }

        //locators
        static By paymentOption = By.xpath("//body/section[@id='ContentArea']/section[1]/div[1]/div[1]/div[1]/div[4]/form[1]/div[3]/ul[1]/li[3]/div[1]/input[1]");
//static By cardNumber = By.cssSelector("input#cardNumber");
//static By securityCode = By.linkText("Enter a valid security code");
    static By cardNumber = By.id("cardNumber");
    static By mm = By.id("expiryMonth");
    static By yy = By.id("expiryYear");
    static By securityCode = By.id("securityCode");
    static By message = By.id("securityCode");
    static By pay = By.id("submitButton");


        // method for choose payment option
        public static void paymentOption() {
            driver.findElement(paymentOption).click();
        }
    // method for enter cardNumber
    public static void enterCardNumber(String cardNum) {
        driver.findElement(cardNumber).sendKeys();
    }
    // method for enter month
    public static void enterMonth(String month) {
        driver.findElement(mm).sendKeys();
    }
    // method for enter cardNumber
    public static void enterYear (String year) {
        driver.findElement(yy).sendKeys();
    }
    // method for enter cvv
    public static void cvv (String cvv) {
        driver.findElement(securityCode).sendKeys();
    }
    // method for choose payment option
    public static void payNow() {
        driver.findElement(pay).click();
    }
    // method for get
    public static String message () { return  driver.findElement(message).getText();
    }

}