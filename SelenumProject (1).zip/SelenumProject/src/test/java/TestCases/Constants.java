package TestCases;

public class Constants {

  public static final String extentPath = "D:\\selenium\\extent.html";
  public static final String imagePath = "D:\\selenium";
  public static final String productPageTitle = "Next Israel";
 // public static final String loginTitle = "My Orders | My Account | Next Directory Online";
  public static final String loginTitle = "Sign In | My Account | Next Directory Online";
  public static final String homePageLeftLinkTitle = "Kitchenware | Kitchen Accessories & Essentials | Next Israel";
  public static final String homePageCenterLinkTitle = "Bathroom | Bathroom Accessories | Next Israel";
  public static final String homePageBannerLinkTitle = "Furniture & Homeware | Next Home & Garden | Next UK";
  public static final String changeLanguageTitle = "Next Official Site: Online Fashion, Kids Clothes & Homeware";
  public static final String changeLanguageTitleBack = "Next Official Site: Online Fashion, Kids Clothes & Homeware";
  public static final String findTitle = "5 pack long sleeve t-shirts from | Next Israel";
  public static final String paymentMessage = " There was an error processing your card payment. Please check your payment details are correct and try again.";
  public static final String searchProduct = "5 Pack Long Sleeve T-Shirts";
}
